(function () {
    'use strict';
})();
