<?php

if (!defined('ABSPATH')) {
    exit;
}

class AIW_Image_Mapper
{
    public function replace_placeholders(string $content, array $image_map, array &$missing_slots = [], array &$unused_slots = []): string
    {
        $unused_slots = array_keys($image_map);
        if ($content === '') {
            return $content;
        }

        $pattern = '/\[(Bild|Image)\s*(\d+)\s*(?::([^\]]*))?\]/i';

        $used_slots = [];
        $content = (string) preg_replace_callback(
            $pattern,
            static function (array $matches) use ($image_map, &$missing_slots, &$used_slots): string {
                $index = isset($matches[2]) ? (int) $matches[2] : 0;
                if ($index <= 0 || !isset($image_map[$index])) {
                    if ($index > 0) {
                        $missing_slots[] = $index;
                    }
                    return '<span class="aiw-missing-image">[MISSING IMAGE ' . esc_html((string) $index) . ']</span>';
                }

                $image_data = $image_map[$index];
                $used_slots[$index] = true;
                $url = isset($image_data['url']) ? esc_url($image_data['url']) : '';
                $alt = isset($image_data['alt']) ? esc_attr($image_data['alt']) : '';
                $id = isset($image_data['id']) ? (int) $image_data['id'] : 0;
                $caption = isset($matches[3]) ? trim((string) $matches[3]) : '';

                $figure = '<figure class="aiw-inline-image wp-block-image size-full">';
                $figure .= '<img src="' . $url . '" alt="' . $alt . '"' . ($id > 0 ? ' class="wp-image-' . esc_attr((string) $id) . '"' : '') . ' />';
                if ($caption !== '') {
                    $figure .= '<figcaption class="wp-element-caption">' . esc_html($caption) . '</figcaption>';
                }
                $figure .= '</figure>';

                return $figure;
            },
            $content
        );

        $unused_slots = array_keys(array_diff_key($image_map, $used_slots));
        return $content;
    }
}
